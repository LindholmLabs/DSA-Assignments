// Problem 2: Social Network
// Description: 
// Course: IT405G - Datastructures and Algorithms
// Authors: William Lindholm, Lili Tran, Victor Adamson
// Date: 29-11-2023
//

#include <iostream>
#include <queue>
#include <vector>
#include <list>
using namespace std;

class Graph {
private:
    int nodes; //Number of nodes
    vector<int>* adj;
public:
    Graph(int nodes);
    void addEdge(int src, int dest); //src == Source node, dest == Destintaion node
    bool isEdge(int src, int dest);
    int getNumNodes();
    void printGraph();
    vector<int> BFS(int src, int dest);
    void printShortPath(int src, int dest);
};

Graph::Graph(int nodes) {
    this->nodes = nodes;
    adj = new vector <int>[nodes];
}

void Graph::addEdge(int src, int dest) {
    adj[src].push_back(dest);
    adj[dest].push_back(src);
}

bool Graph::isEdge(int src, int dest) {
    vector<int>::iterator i;
    for (i = adj[src].begin(); i != adj[src].end(); i++) {
        if (dest == *i) {
            return(true);
        }
        return(false);
    }
}

int Graph::getNumNodes() {
    return nodes;
}

void Graph::printGraph() {
    for (int src = 0; src < nodes; ++src) {
        cout << "\nAdjacency list of node " << src << "\n head ";
        vector<int>::iterator i;
        for (i = adj[src].begin(); i != adj[src].end(); ++i) {
            cout << "-> " << *i << " ";
        }
    }
}

vector<int> Graph::BFS(int src, int dest)
{
    vector<bool> visited;
    visited.resize(nodes, false);
    queue<int> queue;
    vector<int> traversal;
    visited[src] = true;
    queue.push(src);
    int current;
    while (!queue.empty()) {
        current = queue.front();
        queue.pop();
        traversal.push_back(current);
        for (auto adjacent : adj[current]) {
            if (!visited[adjacent]) {
                visited[adjacent] = true;
                queue.push(adjacent);
            }
        }
    }
    return traversal;
}

void Graph::printShortPath(int src, int dest) {
}

int main(){
    Graph network(4);
    network.addEdge(0, 1); //A dislikes B
    network.addEdge(1, 2); //B dislikes C
    network.addEdge(1, 3); //B dislikes D
    network.addEdge(2, 3); //C dislikes D
    network.addEdge(2, 1); //C dislikes B
    network.printGraph();
    
    const int i = network.getNumNodes();
    list<int> nodes[4];
    cout << "\n" << "Number of nodes: " << i << "\n";
    cout << "Breadth First Traversal from A: \n";
    vector<int> traversal = network.BFS(0, 3); //Traversal from source to destination (0 = A, 1 = B, 2 = C, 3 = D)
    
    for (int node : traversal) {
        cout << node << " ";
    }
    //network.printShortPath(0, 3);
}

vector<int> findFriends(Graph network) {
    vector<int> friends;

    return friends;
}

bool isFriend(Graph network) {

    return true;
}